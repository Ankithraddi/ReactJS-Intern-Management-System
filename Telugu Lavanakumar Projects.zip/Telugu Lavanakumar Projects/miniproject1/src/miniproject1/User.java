package miniproject1;


public class User {
	
	public String full_name;
	public String address;
	private String email;
	private String password;
	
	
	
	public String getEmail() 
	{
		return email;
	}

	public void setEmail(String email) 
	{
		this.email = email;
	}



	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}


	public User(String full_name,String address,String email,String password)
	{
		this.full_name=full_name;
		this.password=password;
		this.email=email;
		this.address=address;
		
	}
	
	public User()
	{
		
	}
	
	

}
