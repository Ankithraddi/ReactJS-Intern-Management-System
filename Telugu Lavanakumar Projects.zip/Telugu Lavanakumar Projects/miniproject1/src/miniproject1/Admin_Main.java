package miniproject1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;

public class Admin_Main {
	
	
	public void Admin_Menu() throws SQLException, IOException
	{
		int choice;
		BufferedReader BuffRead= new BufferedReader(new InputStreamReader(System.in));
        Scanner c = new Scanner(System.in);
        int ch;
        System.out.println("************** Hello!  Welcome Admin for Restuarant Operations ***************\n");
     
                    
                    do {
                        System.out.println("------------- List of Operation -------------");
                        System.out.println("1.Insert a new Item");
                        System.out.println("2.Display all the items");
                        System.out.println("3.Update the price of item");
                        System.out.println("4.Delete an Item");
                        System.out.println("5.Disply todays Total Bill");
                        System.out.println("6.Diaplays Month Total Bill");
                        System.out.println("0.Exit from the CRUD Operations");
                        System.out.print("\nPlease select one of the above options: ");
                        choice = c.nextInt();
                        	switch(choice)
                        	{

	                            //To Insert a new Item into the Menu
	                            case 1:DBConnection m4=new DBConnection();
		                                System.out.print("Enter the Item Name: ");
		                                String Item_Name = BuffRead.readLine();
		                                System.out.print("Enter the Item Price: ");
		                                int Item_Price = Integer.parseInt(BuffRead.readLine());
		                                try
		                                {
		                                    //Calling the Insert Method 
		                                    int i = m4.Insert_Admin(Item_Name, Item_Price);
		                                     if(i>0)
		                                     {
		                                         System.out.println("\n\nData successfully inserted into table................\n\n");
		                                     }
		                                     else
		                                     {
		                                         System.out.println("Data not added");
		                                     }
		                                }
		                                catch(Exception e)
		                                {
		                                    System.out.println(e);
		                                }
		                            
		                                break;
		
	                            
	                            
	                            // To Display all the Items present on the Menu
	                            case 2:
	                            	DBConnection m5=new DBConnection();
	                            		
	                            		//here we are calling display method
	                            		m5.view1();
	                            		break; 
	                            
	                            
	                            
	                            // To Update the Price of a particular item from teh Menu using Item No.
	                            case 3:                       
		                                 System.out.print("Enter the Item No which you want to update: ");
		                                 int Item_No = Integer.parseInt(BuffRead.readLine());
		                                 System.out.println("Provide the following details for updation under the Item No: "+Item_No+" -----\n");
		                                 System.out.print("Enter the Updated Item Price: ");
		                                 int price = Integer.parseInt(BuffRead.readLine());  
		                                
		                                 DBConnection m6=new DBConnection();
		                                 try
		                                 {
		                                    //Calling the Update Method
		                                     int i=m6.Update_Admin(Item_No, price );
		                                     if(i>0)
		                                     {
		                                         System.out.println("\n\nThe Item No:"+Item_No+" has been Updated Successfully\n\n");
		                                         
		                                     }
		                                     else
		                                     {
		                                         System.out.println("\n\n Invalid Item Number.............\n\n");
		                                     }
		                                 }
		                                 catch(Exception e)
		                                 {
		                                    System.out.println(e);
		                                 }
		                             
		                                 break;
	
	                            
	                            
	                            
	                            //To Delete an Item from the Menu using Item No.
	                            case 4:
	                            
		                                 System.out.print("\nEnter Item No for deletion: ");
		                                 int Item_no=Integer.parseInt(BuffRead.readLine());
		                                 try
		                                 {
		                                    //Calling the Delete Method
		                                	 DBConnection m7=new DBConnection();
		                                     int i=m7.Delete_Admin(Item_no);
		                                     if(i>0)
		                                     {
		                                         System.out.println("\n\nThe Item No:"+Item_no+" has been Deleted Successfully\n\n");
		                                         
		                                     }              
		                                     else
		                                     {
		                                    	 System.out.println("\n\n Invalid Item Number.............\n\n");
		                                     }
		                                 }
		                                 catch(Exception e)
		                                 {
		                                     System.out.println(e);
		                                 }
		                             
		                                break;
	                                
	                                
	                                
	                            //Displaying Todays Total Bill    
	                            case 5:DBConnection m2=new DBConnection();
	                        			m2.Display_TodayBill();
	                        			break;
	                        		
	                        		
	                            //Displaying Monthly Total Bill   
	                            case 6:DBConnection m3=new DBConnection();
	                        			m3.Display_MonthBill();
	                        			break;
	
	                        			
	                            //To Exit from CRUD Operations
	                            case 0:
	                            		System.out.println("\n\nYou have LogOut Successfully..........!!\n");
	                              

	                            //If Wrong Choice is Selected
	                            default:
	                            		System.out.println("\nError!! Please select the correct option......\n");
                                }
                    }while(choice!=0);
                    
                 
	}

}
