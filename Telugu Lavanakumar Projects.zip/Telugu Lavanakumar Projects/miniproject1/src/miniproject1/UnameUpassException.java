package miniproject1;

public class UnameUpassException extends Exception{

}
