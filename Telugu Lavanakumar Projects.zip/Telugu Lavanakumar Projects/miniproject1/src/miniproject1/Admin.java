package miniproject1;

public class Admin {
	
	private String Admin_Name;
	private String password;
	public String getAdmin_Name() {
		return Admin_Name;
	}
	public void setAdmin_Name(String admin_Name) {
		Admin_Name = admin_Name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Admin()
	{
		Admin_Name="admin";
		password="admin";
		
	}

}
