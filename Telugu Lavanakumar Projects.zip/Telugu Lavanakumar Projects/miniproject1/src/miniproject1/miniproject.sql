create database restaurant;

use restaurant;

create table menu_card(slno int primary key auto_increment,item_name varchar(20),price int);
select * from menu_card;	




create table bill(slno int primary key auto_increment,total_bill int,order_date date);
insert into bill(total_bill,order_date) values (200,'2022-07-24');
insert into bill(total_bill,order_date) values (100,'2022-07-27');
insert into bill(total_bill,order_date) values (140,'2022-07-29');
select * from bill;