package miniproject1;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class User_Main {
	public int total=0;
	public int sum=0;
	public void User_Menu() throws SQLException
	{
		Scanner sc=new Scanner(System.in);
		int item,plates;
		
		String ch="yes";
		
		do
		{
			System.out.print("\n\nSelect which item you want from menu:");
			item=sc.nextInt();
			System.out.print("\nEnter the no of Plates you want:");
			plates=sc.nextInt();
			
			DBConnection m=new DBConnection();
			
			//here we are calling selectitem function
			sum=m.Select_Item(item,plates);
			
			if(sum==0)
			{
				System.out.println("\nPlease select item that is in the list...............");
			}
			{
			total=total+sum;
			
			System.out.println("\nPress Yes for order more items:");
			ch=sc.next();
			}
		}while(ch.equals("yes"));
		
		
		System.out.println("\n\nTotal Bill: "+total);
		DBConnection m1=new DBConnection();
		
		
		//we are inserting bill in database
		m1.Insert_bill(total);
		
		System.out.println("\n\n**************Thank you for ordering*****************");
	}

}
