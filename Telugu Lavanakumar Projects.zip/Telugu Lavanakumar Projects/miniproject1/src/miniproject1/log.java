package miniproject1;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.io.File;
import java.io.IOException;
import java.security.Security;

public class log {
	public Logger logger;

	FileHandler fl;

	public log(String file_name) throws SecurityException, IOException {
		File f = new File(file_name);
		if (!f.exists()) {
			f.createNewFile();
		}
		fl = new FileHandler(file_name, true);
		logger = Logger.getLogger("test");
		logger.addHandler(fl);
		SimpleFormatter formatter = new SimpleFormatter();
		fl.setFormatter(formatter);
	}
}
