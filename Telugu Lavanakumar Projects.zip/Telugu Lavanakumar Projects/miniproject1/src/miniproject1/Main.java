package miniproject1;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;



	
public class Main 
{
	
	
	DBConnection menu_obj1=new DBConnection();
	
	Scanner sc=new Scanner(System.in);
	
	
	//checking admin credentials
	public boolean Admin_Login_Check(String aname,String apassword)
	{
		boolean flag1=false;
		Admin a=new Admin();
		if(a.getAdmin_Name().equals(aname) && a.getPassword().equals(apassword))
		{
			flag1=true; 
		}
		else
		{
			System.out.println("Enter Correct Admin Credentials.......");
		}
		return flag1;
	}
	
	
   //Verifying Login details
	public boolean Login_Check(ArrayList<User> u)
	{
		boolean flag=false;
		String uname,upass;
		System.out.print("\nEnter Username To Login:");
		uname=sc.next();
		System.out.print("\nEnter PassWord To Login:");
		upass=sc.next();
		try {
			
				for(int i=0;i<u.size();i++)
				{
				//checking user username and password
					if(u.get(i).getEmail().equals(uname) && u.get(i).getPassword().equals(upass))
					{
						
						//creating file and writing the logs into the file
						try 
						{
							log my_log = new log("log.txt");
						
							my_log.logger.info("user:"+u.get(i).getEmail());
						

						} 
						catch (Exception e)
						{

						}
			  
						flag=true;		
					}
				}
				if(flag==false)
				{
					UnameUpassException e=new UnameUpassException();
					throw e;
				}
			}
		catch(Exception e)
		{
			try 
			{	//showing the severe messages		
				log my_log = new log("log.txt");
				my_log.logger.severe("Please Enter Correct Username and Password........");
			}
			catch(Exception e1)
			{
				
			}
			System.out.println(e);
			
			
			
		
		}
		return flag;
	}
	
	
	
	

	public static void main(String[] args) throws SQLException, IOException 
	{
		// TODO Auto-generated method stub
		
		int choice,choice1,count=1;
		String name,password,address,email;
		Scanner sc1=new Scanner(System.in);
		Menu_item m1=new Menu_item();
		m1.store_items();
		Main m=new Main();
		//stores user data
	     ArrayList<User> u=new ArrayList<>();
	     DBConnection menu_obj1=new DBConnection();
	     
	    System.out.println("Note: iam using the database username as root and password is Lavanakumar@99\nPlease Change if it neccessary that Connection part is in Menu_Card Class\n");
	    System.out.println("Note: iam using the admin username as surabhi and password is surabhi@99\n\n");
	 	System.out.println("\n****************     Welcome to Surabhi Restraurent    **************\n\n");		
		do {
			//user SignUp and login menu
			
			System.out.println("***********************************************************************");
			System.out.println("\n\n1.Admin.. ");
			System.out.println("2.User..");
			System.out.println("0.Exit..");
			
			System.out.print("\nEnter your Option: ");
			choice=sc1.nextInt();
			
				switch(choice)
				{
					case 1://taking admin username and password
				    		System.out.print("Enter Admin UserName:");
				    		email=sc1.next();
				    		System.out.print("Enter Admin password:");
				    		password=sc1.next();
				    		boolean flag3=m.Admin_Login_Check(email, password);
				    		Admin_Main am=new Admin_Main();
				    		if(flag3==true)
				    		{
				    			
				    			am.Admin_Menu();
				    		}
				    		
		        	
				    		//adding data to list
				    		
				    		break;
					case 2:System.out.println("\n****************     Welcome to Surabhi Restraurent   **************");
						
						   do {
								//user SignUp and login menu
								
								System.out.println("\n\n1.SignUp.. ");
								System.out.println("2.Login..(Before Login you need to SignUp..)");
								System.out.println("0.Exit..");
						
								System.out.print("\nEnter your Option: ");
								choice1=sc1.nextInt();
						
								switch(choice1)
								{
								case 1://Taking the registration from user
										System.out.print("\nEnter User FullName:");
										name=sc1.next();
										System.out.print("Enter User address:");
										address=sc1.next();
										System.out.print("Enter Users Username:");
										email=sc1.next();
										System.out.print("Enter Users password:");
										password=sc1.next();
										
										System.out.println("\n\nSuccessfully Registered........Now You can Login !");
	        	
										//adding data to list
										u.add(new User(name,address,email,password));
										break;
			    			            
								case 2://login function calling
										boolean flag1=m.Login_Check(u);
					    				if(flag1==true)
					    				{
					    					User_Main u1=new User_Main();
					    					menu_obj1.view1();
					    					u1.User_Menu();
					    				}
					    				break;
								case 0:
										
									}
								
						   	}while(choice1!=0);

				}

			
		}while(choice!=0);
	}
}
