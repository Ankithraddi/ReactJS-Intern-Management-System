package miniproject1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public class DBConnection {

public int sum=0;
	
	private static DBConnection jdbc;
	
	//getInstance Method
	public static DBConnection getInstance() 
	{
		
		if(jdbc==null)
		{
			jdbc=new DBConnection();
		}
		
		return jdbc;

	}
	
	
	//Connection method
	private static Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Connection con=null;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurant", "root", "Lavanakumar@99");
		
		return con;
	}
	
	
	//insert1 function is used to store default items
	public int insert1(ArrayList<Menu_item> menuobj) throws SQLException
	{
		Connection c=null;
		PreparedStatement ps=null;
		
		int recordCounter=0;
		
		try
		{
			c=this.getConnection();
			for(int i=0;i<menuobj.size();i++)
			{
				ps=c.prepareStatement("insert into menu_card(item_name,price)values(?,?)");
				
				ps.setObject(1, menuobj.get(i).getItem());
				ps.setObject(2, menuobj.get(i).getPrice());
	
				recordCounter=ps.executeUpdate();
			}
		
		}
		
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
		
		finally
		{
			if(ps!=null)
			{
				ps.close();
			}
			if(c!=null)
			{
				c.close();
			}
		}
		
		return recordCounter;
		
	}
	
	
	//Displaying all items
	public void view1 ( ) throws SQLException
	{
		Connection c=null;
		PreparedStatement ps=null;
		
		ResultSet rs=null;
		
		try
		{
			c=this.getConnection();
			
			ps=c.prepareStatement("select * from menu_card");
			
			rs=ps.executeQuery();
			System.out.println("SlNo          (      item        )            price");
			System.out.println("--------------------------------------------------");
			while(rs.next())
			{
				
				System.out.println(rs.getInt(1)+"                    "+rs.getString(2)+"                       "+rs.getInt(3));
			}
			System.out.println("--------------------------------------------------");
		}
		
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
		
		finally
		{
			if(ps!=null)
			{
				ps.close();
			}
			if(c!=null)
			{
				c.close();
			}
		}
		
		
		
	}
	
	
	//this function is used to order a particular item and no of plates
	public int Select_Item (int slno ,int plates ) throws SQLException
	{
		Connection c=null;
		PreparedStatement ps=null;
		int item_price;
		ResultSet rs=null;
		
		try
		{
			c=this.getConnection();
			
			ps=c.prepareStatement("select * from menu_card where slno="+slno);
			rs=ps.executeQuery();
			while(rs.next())
			{
				if(slno==rs.getInt(1))
				{
					item_price=rs.getInt(3);
					item_price=item_price*plates;
					sum=sum+item_price;
					
					
				}
			}
			
		}
		
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
		
		finally
		{
			if(ps!=null)
			{
				ps.close();
			}
			if(c!=null)
			{
				c.close();
			}
		}
		
		return sum;
		
	}
	
	
	//Inserting User Bill into database
	public void Insert_bill(int total) throws SQLException
	{
		
		Connection c=null;
		PreparedStatement ps=null;
		
		int recordCounter=0;
		
		try
		{
			c=this.getConnection();
	
			ps=c.prepareStatement("insert into bill(total_bill,order_date)values(?,CURDATE())");		
			ps.setInt(1, total);
	
			recordCounter=ps.executeUpdate();
		
			
		}
		
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
		
		finally
		{
			if(ps!=null)
			{
				ps.close();
			}
			if(c!=null)
			{
				c.close();
			}
		}
		
		
	}
	
	
	//Displaying TodayBill
	public void Display_TodayBill() throws SQLException
	{
		Connection c=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		LocalDate today = LocalDate.now();
		try
		{
			c=this.getConnection();
			
			ps=c.prepareStatement("select * from bill where order_date=CURDATE()");
			rs=ps.executeQuery();
			System.out.println("\n\nTotal Today Bills:\n");
			System.out.println("Slno\t\tBillAmount\t\tDate\n");
			while(rs.next())
			{
			System.out.println(rs.getInt(1)+"\t\t"+rs.getInt(2)+"\t\t\t"+rs.getDate(3)+"\n\n");
			}
			
		}
		
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
		
		finally
		{
			if(ps!=null)
			{
				ps.close();
			}
			if(c!=null)
			{
				c.close();
			}
		}
		
		
		
	}
	
	
	
	//this function Displays Monthly total Bill
	public void Display_MonthBill() throws SQLException
	{
		Connection c=null;
		PreparedStatement ps=null;
		
		ResultSet rs=null;
		LocalDate today = LocalDate.now();
		try
		{
			c=this.getConnection();
			
			ps=c.prepareStatement("select * from bill where order_date between '2022/07/01' and '2022/08/03'");
			rs=ps.executeQuery();
			System.out.println("\n\nTotal Monthly Bills:\n");
			
			System.out.println("Slno\t\tBillAmount\t\tDate\n");
			while(rs.next())
			{
			System.out.println(rs.getInt(1)+"\t\t"+rs.getInt(2)+"\t\t\t"+rs.getDate(3)+"\n\n");
			}
			
		}
		
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
		
		finally
		{
			if(ps!=null)
			{
				ps.close();
			}
			if(c!=null)
			{
				c.close();
			}
		}
		
	}
	
	
	
	//this funtion is used to inser new item in table by Admin
	public int Insert_Admin(String name,int price) throws SQLException
	{
		Connection c=null;
		PreparedStatement ps=null;
		
		int recordCounter=0;
		
		try
		{
			c=this.getConnection();
			ps=c.prepareStatement("insert into menu_card(item_name,price)values(?,?)");
			
			ps.setString(1,name);
			ps.setInt(2,price);

		
			recordCounter=ps.executeUpdate();
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		finally
		{
			if(ps!=null)
			{
				ps.close();
			}
			if(c!=null)
			{
				c.close();
			}
		}
		
		return recordCounter;
		
	
	
	
	}
		
	
	//Updating item price in menucard
	public int Update_Admin(int id,int price) throws SQLException
	{
		Connection connect=null;
		PreparedStatement statement=null;
		int recordCounter=0;
		try
		{
			connect=this.getConnection();
			statement=connect.prepareStatement("update menu_card set price=? where slno="+id);
			statement.setInt(1,price);
			
			recordCounter=statement.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(statement!=null)
				{
				statement.close();
				}
			if(connect!=null)
			{
				connect.close();
			}
		}
		return recordCounter;
		
	}
	
	//Delete a Particular Book using Book ID
	public int Delete_Admin(int id) throws SQLException
	{
			Connection connect=null;
			PreparedStatement statement=null;
			int recordCounter=0;
			try
			{
				connect=this.getConnection();
				statement=connect.prepareStatement("delete from menu_card where slno="+id);
				recordCounter=statement.executeUpdate();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				if(statement!=null)
				{
					statement.close();
				}
				if(connect!=null)
				{
					connect.close();
				}
			}
			return recordCounter;
	}
}
