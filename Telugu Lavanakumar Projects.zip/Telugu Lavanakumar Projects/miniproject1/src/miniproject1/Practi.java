package miniproject1;

public class Practi {
	public int b=10;
	public Practi()
	{
		System.out.println("this is 1");
		Practi p1=new Practi(b);
	}
	public Practi(int a)
	{
		System.out.println(a);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Practi p=new Practi();

	}

}
