package com.model;
import com.db.*;

import java.util.ArrayList;

public class Menu_item {
	public Menu_item() 
	{
	
		
	}
	
	
	private String item;
	private int price;
	
	
	
	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	
	//Default List of Items
	ArrayList<Menu_item> List_items()  
	{
		
		Menu_item m1=new Menu_item();
		m1.item="idly";
		m1.price=30;
		Menu_item m2=new Menu_item();
		m2.item="vada";
		m2.price=35;
		Menu_item m3=new Menu_item();
		m3.item="dosa";
		m3.price=45;
		Menu_item m4=new Menu_item();
		m4.item="upma";
		m4.price=30;
		Menu_item m5=new Menu_item();
		m5.item="bujji";
		m5.price=20;
		Menu_item m6=new Menu_item();
		m6.item="rice";
		m6.price=60;
		Menu_item m7=new Menu_item();
		m7.item="puri";
		m7.price=35;
		Menu_item m8=new Menu_item();
		m8.item="tea";
		m8.price=10;
		Menu_item m9=new Menu_item();
		m9.item="cofee";
		m9.price=15;
		
		
		ArrayList<Menu_item> am=new ArrayList<Menu_item>();
		
		am.add(m1);
		am.add(m2);
		am.add(m3);
		am.add(m4);
		am.add(m5);
		am.add(m6);
		am.add(m7);
		am.add(m8);
		am.add(m9);
		
		
		return am;
		
	}
	
	public void store_items()
	{
			Menu_item menuobj=new Menu_item();
			DBConnection  jdbc=DBConnection.getInstance();
		 	ArrayList<Menu_item> amcard=new ArrayList<Menu_item>();
			
			amcard=menuobj.List_items();
			
			 try
			 {
				 int i=jdbc.insert_default_items(amcard);
				 
				 if(i>0)
				 {
					 System.out.println("");
					 
				 }
				 
				 else
				 {
					 System.out.println("Data not added");
				 }
			 }
				 catch(Exception e)
				 {
					 System.out.println(e);
				 }
	}

	

}
