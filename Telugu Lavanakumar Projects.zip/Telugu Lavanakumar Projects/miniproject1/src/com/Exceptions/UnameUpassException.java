package com.Exceptions;

@SuppressWarnings("serial")
public class UnameUpassException extends Exception {

}

